package com.school.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalfiltapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
